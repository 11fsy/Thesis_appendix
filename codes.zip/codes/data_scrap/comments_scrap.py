# 导入自动化模块
from DrissionPage import ChromiumPage
# 导入日期转换模块
from datetime import datetime
# 导入csv模块
import csv

# 创建文件对象
f = open('data_scraped78.csv', mode = 'w', encoding = 'utf-8', newline = '')
# 字典写入方法（最小改动：把原来的 Post_id 改为 Comment_id，并新增 Post_id）
csv_writer = csv.DictWriter(f,fieldnames = [
    'Comment_id',     # ← 原来的 Post_id 改为 Comment_id（写评论ID）
    'Post_id',        # ← 新增：帖子ID（从URL提取的 note_id）
    'Date',
    'Like_count',
    'Comment_count',
    'Location',
    'Comment'
])
# 写入表头
csv_writer.writeheader()

#打开浏览器（实例化浏览器对象） 自定义变量名+浏览器对象
dp = ChromiumPage()
#监听数据包
dp.listen.start('comment/page')

# ===== 最小改动：提取 note_id 作为 Post_id =====
post_url = 'https://www.xiaohongshu.com/explore/67678c1a000000000b016873?xsec_token=ABGelVzVPxSUmWVrqk00gBY4MORdW9Ffz1VvD3zf8hNE4=&xsec_source='
dp.get(post_url)
note_id = post_url.split('/explore/')[-1].split('?')[0]  # ← 提取 24位笔记ID

# 获取数据，监听数据包，做过滤，特征：comment/page
# 构建循环翻页
page = 1
while True:
    print(f'正在采集第{page}页')

    # 等待数据包加载
    r = dp.listen.wait()

    # 获取响应数据: JSON 字典数据
    json_data = r.response.body
    print(json_data)

    # 提取评论列表
    comments = json_data['data']['comments']

    # 遍历评论
    for index in comments:
        key_list = [i for i in index.keys()]
        ip_location = index['ip_location'] if 'ip_location' in key_list else 'Unknown'

        # 提取时间
        t = str(index['create_time'])[:-3]
        date = str(datetime.fromtimestamp(int(t)))

        # 构建要写入的字典
        dit = {
            'Comment_id': index['id'],                 # ← 现在写评论ID
            'Post_id': note_id,                        # ← 新增：同一帖所有评论写同一个 note_id
            'Date': date,
            'Like_count': index['like_count'],
            'Comment_count': index['sub_comment_count'],
            'Location': ip_location,
            'Comment': index['content'],
        }

        # 写入 CSV
        csv_writer.writerow(dit)
        print(dit)

        # 滚动到对应评论元素
        id_ = index['id']
        tab = dp.ele(f'#comment-{id_}')
        dp.scroll.to_see(tab)

    # 自动停止判断：没有更多数据
    has_more = json_data['data'].get('has_more', False)
    if not has_more:
        print("已到最后一页，自动停止采集。")
        break

    page += 1
