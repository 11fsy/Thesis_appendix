from statsmodels.stats.proportion import proportions_ztest

# Example numbers (replace with your real values)
n_total = 9799
n_positive = 5500  # replace with your count

stat, p_val = proportions_ztest(count=n_positive, nobs=n_total, value=0.5, alternative='larger')

print("Z-statistic:", stat)
print("p-value:", p_val)

