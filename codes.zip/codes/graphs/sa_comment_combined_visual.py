import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

# ============================================================
# 1. File Paths
# ============================================================
POST_FILE = "post_final_binary_result.csv"
COMMENT_FILE = "comment_final_binary_result.csv"
OUTPUT_MATRIX_CSV = "post_comment_sentiment_matrix.csv"
OUTPUT_FIG = "post_comment_sentiment_heatmap.png"

# ============================================================
# 2. Load Sentiment Results
# ============================================================
posts = pd.read_csv(POST_FILE)
comments = pd.read_csv(COMMENT_FILE)

posts = posts.rename(columns={"predicted_label": "post_sentiment"})
comments = comments.rename(columns={"predicted_label": "comment_sentiment"})

df = comments.merge(posts[["post_id", "post_sentiment"]],
                    on="post_id", how="left")

# ============================================================
# 3. Build 2×2 Matrix
# ============================================================
ct = (
    pd.crosstab(df["comment_sentiment"], df["post_sentiment"],
                normalize="columns") * 100
).round(2)

ct.to_csv(OUTPUT_MATRIX_CSV, encoding="utf-8-sig")
print(ct)

# ============================================================
# 4. Custom Colormap (consistent with your theme)
# ============================================================

# Light gray → soft blue → deep blue
colors = ["#E6E6E6", "#A7C3DD", "#0072B2"]
custom_cmap = LinearSegmentedColormap.from_list("custom_blue", colors)

# ============================================================
# 5. Plot Heatmap
# ============================================================
plt.figure(figsize=(7, 5))

plt.imshow(ct, cmap=custom_cmap, aspect="equal")

# Draw cell borders
ax = plt.gca()
for i in range(ct.shape[0]):
    for j in range(ct.shape[1]):
        ax.add_patch(plt.Rectangle(
            (j - 0.5, i - 0.5),
            1, 1,
            fill=False,
            edgecolor="black",
            linewidth=2
        ))

# Cell text
for (i, j), value in np.ndenumerate(ct.values):
    plt.text(j, i,
             f"{value:.2f}%",
             ha="center", va="center",
             fontsize=14, color="black")

# Axis ticks & labels
plt.xticks(range(len(ct.columns)), ct.columns, fontsize=11)
plt.yticks(range(len(ct.index)), ct.index, fontsize=11)

plt.xlabel("Post Sentiment", fontsize=8)
plt.ylabel("Comment Sentiment", fontsize=8)

plt.title("Sentiment Distribution of Comments\nUnder Different Post Sentiments",
          fontsize=11)

# Colorbar
cbar = plt.colorbar(label="Percentage (%)")
cbar.ax.set_yticklabels([f"{tick:.2f}%" for tick in cbar.get_ticks()])

plt.tight_layout()
plt.savefig(OUTPUT_FIG, dpi=300)
plt.show()

print(f"📊 Saved heatmap to: {OUTPUT_FIG}")
