import matplotlib.pyplot as plt
import pandas as pd
from pathlib import Path

# === Paths ===
BASE_DIR = Path("./")
INPUT_FILE = BASE_DIR / "pipeline_output" / "merged_comments_topics.csv"
OUTPUT_DIR = BASE_DIR / "pipeline_output"

# === Load data ===
df = pd.read_csv(INPUT_FILE)
df = df[df["topic"] != -1]

comment_counts = df.groupby("topic").size().sort_index()

# =============================
# 📊 AESTHETIC BAR CHART
# =============================

fig, ax = plt.subplots(figsize=(9, 5.5))

bars = ax.bar(
    [f"Topic {int(t)}" for t in comment_counts.index],
    comment_counts.values,
    color="#0072B2",
    edgecolor="#4D4D4D",
    linewidth=0.8
)

# --- Title & labels ---
ax.set_title("Number of Comments per Post Topic", fontsize=12, pad=12)
ax.set_xlabel("Post Topic", fontsize=9)
ax.set_ylabel("Number of Comments", fontsize=9)

# --- Grid (subtle, academic style) ---
ax.yaxis.grid(True, linestyle="--", alpha=0.4)
ax.xaxis.grid(False)

# --- Remove unnecessary spines ---
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

# --- Value labels ---
for bar in bars:
    height = bar.get_height()
    ax.text(
        bar.get_x() + bar.get_width() / 2,
        height + max(comment_counts.values) * 0.02,
        f"{int(height)}",
        ha="center",
        va="bottom",
        fontsize=10
    )

plt.tight_layout()
plt.savefig(OUTPUT_DIR / "comment_count_per_topic.png", dpi=300)
plt.close()
