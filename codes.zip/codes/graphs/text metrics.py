import matplotlib.pyplot as plt
import numpy as np

# Categories
metrics = ["Total characters", "Longest text", "Shortest text", "Average length"]

# Values
post_values = [39739, 1179, 31, 375]
comment_values = [473966, 300, 1, 42]

x = np.arange(len(metrics))
width = 0.38

# Colorblind-safe colors (Okabe–Ito)
post_color = "#0072B2"     # blue
comment_color = "#E69F00"  # orange

plt.figure(figsize=(10, 6))

# Bars
bars1 = plt.bar(x - width/2, post_values, width,
                label="Post (Title + Content)", color=post_color)
bars2 = plt.bar(x + width/2, comment_values, width,
                label="Comment", color=comment_color)

# --- Optional: log scale for readability ---
plt.yscale("log")

# Add bar labels
for bar in bars1 + bars2:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2,
             height * 1.05,
             f"{int(height)}",
             ha='center', va='bottom', fontsize=9)

# Labels and title
plt.xticks(x, metrics)
plt.xlabel("Text Metrics",fontsize=12)  # ✅ Added X-axis label here
plt.ylabel("Characters (log scale)",fontsize=12)
plt.title("Comparison of Text Metrics Between Posts and Comments",fontsize=16)
plt.legend()

# Grid
plt.grid(axis="y", linestyle="--", alpha=0.4)

plt.tight_layout()
plt.show()
