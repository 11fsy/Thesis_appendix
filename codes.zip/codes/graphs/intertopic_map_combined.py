# ============================================================
# ⭐ Final Non-Overlapping Intertopic Map
# ============================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from bertopic import BERTopic
from sentence_transformers import SentenceTransformer
from adjustText import adjust_text
import matplotlib
from bertopic_comment import BASE_DIR

# ------------------------------
# English font (no Chinese)
# ------------------------------
matplotlib.rcParams["font.family"] = "Arial"

# ------------------------------
# Load BERTopic model
# ------------------------------
model_path = "/Users/fushiyi/Desktop/Helsinki/masters_thesis/coding/bertopic_model_comments_paper_v8_raw"
topic_model = BERTopic.load(model_path)

# ------------------------------
# Get topics
# ------------------------------
topic_info = topic_model.get_topic_info()
valid_topics = [t for t in topic_info["Topic"] if t != -1]
topic_sizes = {row["Topic"]: row["Count"] for _, row in topic_info.iterrows() if row["Topic"] != -1}
topic_emb = topic_model.topic_embeddings_[valid_topics]

# ------------------------------
# Three main categories
# ------------------------------
categories = ["Family", "Work", "Emotion"]
encoder = SentenceTransformer("shibing624/text2vec-base-chinese")
cat_emb = encoder.encode(categories, normalize_embeddings=True)

# ------------------------------
# Combine embeddings
# ------------------------------
all_emb = np.vstack([cat_emb, topic_emb])
pca = PCA(n_components=2, random_state=42)
coords = pca.fit_transform(all_emb)

cat_coords = coords[:3]
topic_coords = coords[3:]

# ------------------------------
# Add jitter so circles do not overlap
# ------------------------------
rng = np.random.default_rng(42)
topic_coords = topic_coords + rng.normal(0, 0.12, topic_coords.shape)  # small spread

# ------------------------------
# Circle sizes
# ------------------------------
max_size = max(topic_sizes.values())
scale = 3500 / max_size   

# ------------------------------
# PLOT
# ------------------------------
plt.figure(figsize=(13, 13))

# --- Main categories ---
plt.scatter(cat_coords[:, 0], cat_coords[:, 1],
            s=2600, color="#93C5FD", edgecolor="black")

for i, label in enumerate(categories):
    plt.text(cat_coords[i, 0], cat_coords[i, 1],
             label, fontsize=18, weight="bold",
             ha="center", va="center")

# --- Topics ---
texts = []

for i, tid in enumerate(valid_topics):
    x, y = topic_coords[i]
    size = topic_sizes[tid] * scale

    # bubble
    plt.scatter(x, y, s=size + 900,
                color="#CBD5E1", edgecolor="black", alpha=0.95)

    # label
    txt = plt.text(
    x,
    y-0.005,   # ⭐ 往下移动一点（你可以调成 0.12 / 0.15）
    f"Topic {tid}\nsize={topic_sizes[tid]}",
    fontsize=12,
    ha="center",
    va="center"
)

    texts.append(txt)

# --- Adjust labels to avoid overlap ---
adjust_text(
    texts,
    expand_points=(1.5, 1.5),
    expand_text=(1.3, 1.3),
    arrowprops=dict(arrowstyle="-", lw=0)
)

# Axis
plt.axhline(0, color="black", lw=1)
plt.axvline(0, color="black", lw=1)

plt.title("Intertopic Distance Map(Comments)", fontsize=22)
plt.xticks([])
plt.yticks([])
plt.tight_layout()

outpath = BASE_DIR / "intertopic_map_no_overlap.png"
plt.savefig(outpath, dpi=300)
plt.show()

print("✅ Saved:", outpath)
