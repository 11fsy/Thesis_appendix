import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl

# === Global style settings ===
mpl.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans']
mpl.rcParams['axes.unicode_minus'] = False

COLOR_BLUE = "#0072B2"

# === 1. Load data ===
df = pd.read_csv("post_data/merged_posts_data.csv")

# === 2. Convert dates ===
df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
df = df.dropna(subset=["Date"])

# === 3. Extract month (YYYY-MM) ===
df["month"] = df["Date"].dt.to_period("M").astype(str)

# === 4. Build full continuous month range ===
all_months = pd.period_range(
    start=df["Date"].min().to_period("M"),
    end=df["Date"].max().to_period("M"),
    freq="M"
).astype(str)

# === 5. Count posts per month, reindex to include blank months ===
monthly_counts = df.groupby("month").size().reindex(all_months, fill_value=0)
counts = monthly_counts.values

# === 6. Numerical x-values for histogram bins ===
x = np.arange(len(all_months))

# === 7. Plot histogram-style bar chart ===
fig, ax = plt.subplots(figsize=(14, 6))

bars = ax.bar(
    x,
    counts,
    width=0.9,
    color=COLOR_BLUE,
    edgecolor="black",
    linewidth=1.2
)

# === 8. Add frequency labels ===
for rect, value in zip(bars, counts):
    ax.text(
        rect.get_x() + rect.get_width() / 2,
        value + 0.2,
        str(int(value)),
        ha="center",
        va="bottom",
        fontsize=10
    )

# === 9. Month labels ===
ax.set_xticks(x)
ax.set_xticklabels(all_months, rotation=45, fontsize=11)

# === 10. Title + axis labels with consistent style ===
ax.set_title("Number of Posts by Month", fontsize=22)
ax.set_xlabel("Month", fontsize=16)
ax.set_ylabel("Number of Posts", fontsize=16)

# === 11. Thick outer border ===
for spine in ax.spines.values():
    spine.set_linewidth(1.3)

plt.tight_layout()
plt.show()

print("\nMonthly counts (including empty months):")
print(monthly_counts)
