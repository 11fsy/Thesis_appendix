# Pipeline: Topic Modeling + Sentiment Merge + Bar Chart

import pandas as pd
from pathlib import Path
from bertopic import BERTopic
from bertopic.vectorizers import ClassTfidfTransformer
from sentence_transformers import SentenceTransformer
from umap import UMAP
from hdbscan import HDBSCAN
from sklearn.feature_extraction.text import CountVectorizer
import jieba
import matplotlib.pyplot as plt
import numpy as np

# === Paths ===
BASE_DIR = Path("./")
POST_FILE = BASE_DIR / "posts_clean.csv"
COMMENT_FILE = BASE_DIR / "comment_final_binary_result.csv"
OUTPUT_DIR = BASE_DIR / "pipeline_output"
OUTPUT_DIR.mkdir(exist_ok=True)

# === Load posts ===
df_posts = pd.read_csv(POST_FILE)
texts = (df_posts["title"].fillna("") + " " + df_posts["text"].fillna("")).tolist()
post_ids = df_posts["post_id"].tolist()

# === Tokenizer ===
def jieba_tokenizer(text):
    return [w for w in jieba.cut(text) if len(w.strip()) > 1]

vectorizer_model = CountVectorizer(
    tokenizer=jieba_tokenizer,
    min_df=3,
    max_df=0.9
)
ctfidf_model = ClassTfidfTransformer(reduce_frequent_words=True)

# === UMAP ===
umap_model = UMAP(
    n_neighbors=10,
    n_components=5,
    min_dist=0.15,
    metric="cosine",
    random_state=42
)

# === HDBSCAN ===
hdbscan_model = HDBSCAN(
    min_cluster_size=5,
    min_samples=3,
    metric="euclidean",
    cluster_selection_method='eom',
    prediction_data=True
)

# === Embedding Model ===
embedding_model = SentenceTransformer(
    "Alibaba-NLP/gte-multilingual-base",
    trust_remote_code=True
)

# === BERTopic model ===
topic_model = BERTopic(
    embedding_model=embedding_model,
    umap_model=umap_model,
    hdbscan_model=hdbscan_model,
    vectorizer_model=vectorizer_model,
    ctfidf_model=ctfidf_model,
    top_n_words=10,
    language="chinese",
    verbose=True
)

topics, probs = topic_model.fit_transform(texts)
topic_model.reduce_topics(texts, nr_topics=4)

doc_info = topic_model.get_document_info(texts)

df_topics = pd.DataFrame({
    "post_id": post_ids,
    "text": texts,
    "topic": doc_info["Topic"]
})
df_topics.to_csv(OUTPUT_DIR / "post_topics.csv", index=False)

# === Load comment sentiment ===
df_comments = pd.read_csv(COMMENT_FILE)

# === Merge posts + topics + comments ===
merged = df_comments.merge(df_topics[["post_id", "topic"]], on="post_id", how="left")
merged.to_csv(OUTPUT_DIR / "merged_comments_topics.csv", index=False)

# === Sentiment per topic ===
merged_no_outlier = merged[merged["topic"] != -1].copy()

summary = (
    merged_no_outlier
    .groupby(["topic", "predicted_label"])
    .size()
    .unstack(fill_value=0)
    .sort_index()
)

cols = [c for c in ["Negative", "Positive"] if c in summary.columns]
summary = summary[cols]
summary.to_csv(OUTPUT_DIR / "sentiment_by_topic.csv")

# =============================
# 📊 CONSISTENT STYLE BAR CHART
# =============================
ax = summary.plot(
    kind="bar",
    figsize=(10, 6),
    color=["#999999", "#0072B2"]
)

ax.set_title("Sentiment Distribution of Comments per Post Topic", fontsize=16)
ax.set_xlabel("Topic", fontsize=12)
ax.set_ylabel("Count", fontsize=12)
ax.set_xticklabels([f"Topic {int(t)}" for t in summary.index], rotation=0, fontsize=11)

for container in ax.containers:
    ax.bar_label(container, fmt="%d", padding=3, fontsize=10)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / "sentiment_bar_chart_counts.png", dpi=300)
plt.close()

# =============================
# 📈 CONSISTENT STYLE LOLLIPOP
# =============================
pos_mean = merged_no_outlier.groupby("topic")["positive_score"].mean()
pos_mean.to_csv(OUTPUT_DIR / "positive_score_mean_by_topic.csv")

fig, ax2 = plt.subplots(figsize=(10, 6))

dot_color = "#0072B2"
line_color = "#999999"

df_sorted = pos_mean.sort_values(ascending=True)
topics_sorted = df_sorted.index.values
values_sorted = df_sorted.values
y_positions = np.arange(len(df_sorted))

ax2.hlines(y_positions, xmin=0, xmax=values_sorted, color=line_color, linewidth=3)
ax2.plot(values_sorted, y_positions, "o", color=dot_color, markersize=10)

ax2.set_title("Average Positive Score of Comments per Post Topic", fontsize=16)
ax2.set_xlabel("Mean Positive Score", fontsize=12)
ax2.set_ylabel("Topic", fontsize=12)

ax2.set_yticks(y_positions)
ax2.set_yticklabels([f"Topic {int(t)}" for t in topics_sorted], fontsize=11)
ax2.set_xlim(0, values_sorted.max() + 0.03)

for x, y in zip(values_sorted, y_positions):
    ax2.text(x + 0.01, y, f"{x:.2f}", va='center', fontsize=10)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / "sentiment_lollipop_positive_score.png", dpi=300)
plt.close()
