import pandas as pd
from pathlib import Path
from natsort import natsorted

# === 1) 路径 ===
BASE_DIR = Path("/Users/fushiyi/Desktop/Helsinki/master's thesis/coding")

# === 2) 获取所有 data_scraped*.csv 文件 ===
files = natsorted((BASE_DIR / "comments_data").glob("data_scraped*.csv"))

print(f"✅ 找到 {len(files)} 个文件：")
for f in files:
    print("   -", f.name)

# === 3) 合并 csv ===
dfs = []
total_count = 0

for file in files:
    df = pd.read_csv(file, encoding="utf-8")
    total_count += df.shape[0]
    dfs.append(df)

merged_df = pd.concat(dfs, ignore_index=True)

# === 4) 保存合并后的文件 ===
output_file = BASE_DIR / "merged_data.csv"
merged_df.to_csv(output_file, index=False, encoding="utf-8-sig")

print("🎉 合并完成！")
print(f"📌 合并后总行数（不去重）: {total_count}")
print(f"💾 保存位置： {output_file}")

# -------------------------------------------------------------
# === Character count metrics for comments ===
# -------------------------------------------------------------

print("\n=== COLUMN NAMES FOUND ===")
print(list(merged_df.columns))

# 自动识别评论内容字段：优先 text > comment > Comment
if "text" in merged_df.columns:
    content_col = "text"
elif "comment" in merged_df.columns:
    content_col = "comment"
elif "Comment" in merged_df.columns:
    content_col = "Comment"
else:
    raise ValueError("❌ No column named 'text', 'comment' or 'Comment' found.")

# ✅ 过滤空白评论（包括 NaN / 空字符串 / 全是空格）
merged_df[content_col] = merged_df[content_col].fillna("")  # 填空值
filtered_df = merged_df[merged_df[content_col].str.strip() != ""]  # 过滤空白

print(f"\n✅ 非空评论数量: {len(filtered_df)}")

# ✅ 计算字符长度
filtered_df["content_len"] = filtered_df[content_col].str.len()

# ✅ Summary dictionary
summary = {
    "Metric": ["Total Characters", "Longest Text (characters)", "Shortest Text (characters)", "Average Length (characters)"],
    "Content": [
        filtered_df["content_len"].sum(),
        filtered_df["content_len"].max(),
        filtered_df["content_len"].min(),
        round(filtered_df["content_len"].mean(), 2)
    ]
}

summary_df = pd.DataFrame(summary)

print("\n===== Comment Character Length Summary (after filtering blanks) =====")
print(summary_df)

# 保存 summary
summary_df.to_csv(BASE_DIR / "character_length_summary_comments.csv", index=False, encoding="utf-8-sig")
print("\n✅ Summary exported: character_length_summary_comments.csv")
