# === 0. 导入依赖 ===
import pandas as pd
import jieba
from pathlib import Path
from bertopic import BERTopic
from bertopic.vectorizers import ClassTfidfTransformer
from sentence_transformers import SentenceTransformer
from umap import UMAP
from hdbscan import HDBSCAN
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# 设置字体为 Mac 常见中文字体
plt.rcParams['font.family'] = 'PingFang HK'   # 或 PingFang SC, Heiti SC, Songti SC

# 避免负号变成方块
plt.rcParams['axes.unicode_minus'] = False


# --- PCA for visualizations ---
from sklearn.decomposition import PCA
import plotly.express as px
import plotly.figure_factory as ff
import numpy as np


# === 1. 基础路径与输入文件 ===
BASE_DIR = Path("/Users/fushiyi/Desktop/Helsinki/masters_thesis/coding/")
input_file = BASE_DIR / "posts_clean.csv"
df = pd.read_csv(input_file)

assert "text" in df.columns, "❌ 缺少 text 欄位"
texts = (df["title"].fillna("") + " " + df["text"].fillna("")).astype(str).tolist()
print(f"📄 有效文本數量：{len(texts)}")


# === 2. 分词与停用词（你第一次用的） ===
def jieba_tokenizer(text):
    return [w for w in jieba.cut(text) if len(w.strip()) > 1]

stopword_files = [
    BASE_DIR / "HIT.txt",
    BASE_DIR / "scu_stopwords.txt",
    BASE_DIR / "cn_stopwords.txt",
    BASE_DIR / "baidu_stopwords.txt",
    BASE_DIR / "stopwords-zh.txt"
]

stop_words = set()
for file in stopword_files:
    try:
        with open(file, encoding="utf-8") as f:
            stop_words.update([w.strip() for w in f if w.strip()])
    except FileNotFoundError:
        print(f"⚠️ 未找到文件：{file}")
stop_words = sorted(stop_words)

print(f"✅ 共加载停用词 {len(stop_words)} 个")


# === 3. CountVectorizer（原版参数） ===
vectorizer_model = CountVectorizer(
    tokenizer=jieba_tokenizer,
    stop_words=stop_words,
    min_df=3,        
    max_df=0.9       
)

ctfidf_model = ClassTfidfTransformer(reduce_frequent_words=True)


# === 4. UMAP（你最初设置） ===
umap_model = UMAP(
    n_neighbors=10,
    n_components=5,         # ⭐ 最初版本的核心参数
    min_dist=0.15,
    metric="cosine",
    random_state=42
)

# === 5. HDBSCAN（你最初设置） ===
hdbscan_model = HDBSCAN(
    min_cluster_size=5,
    min_samples=3,
    metric="euclidean",
    cluster_selection_method='eom',
    prediction_data=True
)

# === 6. Embedding 模型 ===
embedding_model = SentenceTransformer("Alibaba-NLP/gte-multilingual-base", trust_remote_code=True)

# === 7. 创建 BERTopic 模型（最初设置） ===
topic_model = BERTopic(
    embedding_model=embedding_model,
    umap_model=umap_model,
    hdbscan_model=hdbscan_model,
    vectorizer_model=vectorizer_model,
    ctfidf_model=ctfidf_model,
    top_n_words=10,
    language="chinese",
    verbose=True
)

topics, probs = topic_model.fit_transform(texts)
topic_model.reduce_topics(texts, nr_topics=4)

print("✅ 已成功聚合為 4 個主題（完全使用最初参数）")


# === 8. 输出主题摘要 ===
topic_info = topic_model.get_topic_info()
topic_info.to_excel(BASE_DIR / "topic_summary_originalparams.xlsx", index=False)


# === 9. 主题关键词 ===
keywords_weighted = []
for topic_id in topic_model.get_topics().keys():
    if topic_id == -1:
        continue
    for word, weight in topic_model.get_topic(topic_id):
        keywords_weighted.append({
            "topic": topic_id,
            "word": word,
            "weight": weight
        })

df_kw = pd.DataFrame(keywords_weighted)
df_kw.sort_values(["topic", "weight"], ascending=[True, False], inplace=True)
df_kw.to_excel(BASE_DIR / "topic_keywords_originalparams.xlsx", index=False)


# === 10. 代表文本 ===
def find_tfidf_representative_docs(topic_model, texts, top_k=3):
    topics = topic_model.get_topics()
    vectorizer = topic_model.vectorizer_model
    tfidf = vectorizer.fit_transform(texts)
    
    representative_texts = {}
    for topic_id, words in topics.items():
        if topic_id == -1:
            continue
        topic_terms = [w for w, _ in words]
        topic_tfidf = vectorizer.transform([' '.join(topic_terms)])
        sims = cosine_similarity(tfidf, topic_tfidf).flatten()
        best_idx = sims.argsort()[-top_k:][::-1]
        representative_texts[topic_id] = [texts[i] for i in best_idx]
    
    return representative_texts

rep_docs = find_tfidf_representative_docs(topic_model, texts, top_k=3)

for i, row in topic_info.iterrows():
    tid = row["Topic"]
    if tid in rep_docs:
        topic_info.at[i, "Representative_Docs"] = str(rep_docs[tid])

topic_info.to_excel(BASE_DIR / "topic_summary_originalparams.xlsx", index=False)


# === 11. 按主题输出文档 ===
df_result = pd.DataFrame({
    "text": texts,
    "topic": topics
})

output_dir = BASE_DIR / "topic_outputs_originalparams"
output_dir.mkdir(parents=True, exist_ok=True)

for topic_id in sorted(topic_info["Topic"]):
    if topic_id == -1:
        continue
    df_result[df_result["topic"] == topic_id] \
        .to_csv(output_dir / f"topic_{topic_id}.csv", index=False)

# =====================================================
# ⭐⭐⭐ 14. Static Intertopic Distance Map  ⭐⭐⭐
# =====================================================

# =====================================================
# ⭐⭐⭐ Four-Quadrant Intertopic Distance Map + Size Labels ⭐⭐⭐
# =====================================================

print("\n🧭 Generating four-quadrant intertopic distance map…")

import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

# ---- 1. Extract embeddings ----
embeddings = topic_model._extract_embeddings(texts)

# ---- 2. Reduce to 2D ----
pca = PCA(n_components=2, random_state=42)
coords_2d = pca.fit_transform(embeddings)

# ---- 3. REAL TOPICS (exclude -1) ----
valid_topics = [0, 1, 2]

centers = []
sizes = []

for tid in valid_topics:
    idx = np.where(np.array(topics) == tid)[0]
    centers.append(coords_2d[idx].mean(axis=0))
    sizes.append(len(idx))

centers = np.array(centers)
sizes = np.array(sizes)

# ---- 4. Scale bubble size ----
size_scaled = (sizes / np.max(sizes)) * 2500 + 900

# ---- 5. Plot figure ----
fig, ax = plt.subplots(figsize=(8, 8))

# Bubbles
ax.scatter(
    centers[:, 0],
    centers[:, 1],
    s=size_scaled,
    color="#CBD5E1",
    edgecolor="#475569",
    alpha=0.9
)

# ---- 6. Text label with SIZE ----
# ---- 先扩一点坐标轴，给文字留空间 ----
x_min, x_max = centers[:, 0].min(), centers[:, 0].max()
y_min, y_max = centers[:, 1].min(), centers[:, 1].max()

padding_x = (x_max - x_min) * 0.25
padding_y = (y_max - y_min) * 0.25

ax.set_xlim(x_min - padding_x, x_max + padding_x)
ax.set_ylim(y_min - padding_y, y_max + padding_y)

y_range = (y_max - y_min)

# ---- 在气泡附近画文字（根据位置决定要不要下移）----
for i, tid in enumerate(valid_topics):
    base_x = centers[i, 0]
    base_y = centers[i, 1]

    # 默认轻微下移一点
    dy = -0.03 * y_range

    # ⚠️ 如果本来就很靠下，再往下就要贴到底了，那就不要偏移
    if base_y + dy < y_min + 0.05 * y_range:
        dy = 0.0

    ax.text(
        base_x,
        base_y + dy,
        f"Topic {tid}\n(n={sizes[i]})",
        fontsize=14,
        ha="center",
        va="center",
        fontweight="bold",
        color="#1E293B"
    )


# ---- 8. Style ----
ax.set_title("Intertopic Distance Map(Posts)", fontsize=22, fontweight="bold")
ax.set_xlabel("D1", fontsize=16)
ax.set_ylabel("D2", fontsize=16)
ax.set_aspect("equal", adjustable="datalim")
ax.set_xticks([])
ax.set_yticks([])
ax.grid(color="#E2E8F0", linestyle="-", linewidth=0.7)

# ---- 9. Save ----
save_path = BASE_DIR / "intertopic_distance_map_quadrants_with_size.png"
plt.savefig(save_path, dpi=300, bbox_inches="tight")
plt.show()

print(f"✅ Saved map with size labels:\n    {save_path}")
