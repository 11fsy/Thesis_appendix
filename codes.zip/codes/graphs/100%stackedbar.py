# Pipeline: Topic Modeling + Sentiment Merge + Bar Chart

import pandas as pd
from pathlib import Path
from bertopic import BERTopic
from bertopic.vectorizers import ClassTfidfTransformer
from sentence_transformers import SentenceTransformer
from umap import UMAP
from hdbscan import HDBSCAN
from sklearn.feature_extraction.text import CountVectorizer
import jieba
import matplotlib.pyplot as plt
import numpy as np

# === Paths ===
BASE_DIR = Path("./")
POST_FILE = BASE_DIR / "posts_clean.csv"
COMMENT_FILE = BASE_DIR / "comment_final_binary_result.csv"
OUTPUT_DIR = BASE_DIR / "pipeline_output"
OUTPUT_DIR.mkdir(exist_ok=True)

# === Load posts ===
df_posts = pd.read_csv(POST_FILE)
texts = (df_posts["title"].fillna("") + " " + df_posts["text"].fillna("")).tolist()
post_ids = df_posts["post_id"].tolist()

# === Tokenizer ===
def jieba_tokenizer(text):
    return [w for w in jieba.cut(text) if len(w.strip()) > 1]

vectorizer_model = CountVectorizer(
    tokenizer=jieba_tokenizer,
    min_df=3,
    max_df=0.9
)
ctfidf_model = ClassTfidfTransformer(reduce_frequent_words=True)

# === UMAP ===
umap_model = UMAP(
    n_neighbors=10,
    n_components=5,
    min_dist=0.15,
    metric="cosine",
    random_state=42
)

# === HDBSCAN ===
hdbscan_model = HDBSCAN(
    min_cluster_size=5,
    min_samples=3,
    metric="euclidean",
    cluster_selection_method='eom',
    prediction_data=True
)

# === Embedding Model ===
embedding_model = SentenceTransformer(
    "Alibaba-NLP/gte-multilingual-base",
    trust_remote_code=True
)

# === BERTopic model ===
topic_model = BERTopic(
    embedding_model=embedding_model,
    umap_model=umap_model,
    hdbscan_model=hdbscan_model,
    vectorizer_model=vectorizer_model,
    ctfidf_model=ctfidf_model,
    top_n_words=10,
    language="chinese",
    verbose=True
)

topics, probs = topic_model.fit_transform(texts)
topic_model.reduce_topics(texts, nr_topics=4)

doc_info = topic_model.get_document_info(texts)

df_topics = pd.DataFrame({
    "post_id": post_ids,
    "text": texts,
    "topic": doc_info["Topic"]
})
df_topics.to_csv(OUTPUT_DIR / "post_topics.csv", index=False)

# === Load comment sentiment ===
df_comments = pd.read_csv(COMMENT_FILE)

# === Merge posts + topics + comments ===
merged = df_comments.merge(df_topics[["post_id", "topic"]], on="post_id", how="left")
merged.to_csv(OUTPUT_DIR / "merged_comments_topics.csv", index=False)

# === Sentiment per topic ===
merged_no_outlier = merged[merged["topic"] != -1].copy()

summary = (
    merged_no_outlier
    .groupby(["topic", "predicted_label"])
    .size()
    .unstack(fill_value=0)
    .sort_index()
)

# Keep column order consistent
cols = [c for c in ["Positive", "Negative"] if c in summary.columns]
summary = summary[cols]
summary.to_csv(OUTPUT_DIR / "sentiment_by_topic.csv")

# ======================================
# 📊 STACKED BAR CHART (MATCH SCRIPT 1)
# ======================================

# Convert count → proportion
df_props = summary.div(summary.sum(axis=1), axis=0)

topic_labels = [f"Topic {int(t)}" for t in df_props.index]

fig, ax = plt.subplots(figsize=(12, 7))

colors = {
    "Negative": "#999999",  # gray
    "Positive": "#0072B2"   # blue
}

df_props.plot(
    kind="bar",
    stacked=True,
    ax=ax,
    color=[colors[col] for col in df_props.columns],
    width=0.6,
    edgecolor="black"
)

# Percentage labels
for i, topic in enumerate(df_props.index):
    bottom = 0
    for sentiment in df_props.columns:
        value = df_props.loc[topic, sentiment]
        if value > 0.01:
            ax.text(
                i,
                bottom + value / 2,
                f"{value:.0%}",
                ha="center",
                va="center",
                fontsize=11,
                color="white" if sentiment == "Positive" else "black"
            )
        bottom += value

ax.set_xticks(range(len(topic_labels)))
ax.set_xticklabels(topic_labels, rotation=0)
ax.set_ylabel("Proportion", fontsize=12)
ax.set_xlabel("Topics", fontsize=12)
ax.set_title("Sentiment Distribution of Comments per Post Topic", fontsize=16)

ax.legend(title="Sentiment")
ax.grid(axis="y", linestyle="--", alpha=0.4)

ax.set_facecolor("white")
fig.patch.set_facecolor("white")

plt.tight_layout()
plt.savefig(OUTPUT_DIR / "sentiment_stacked_bar.png", dpi=300)
plt.close()

