import pandas as pd
import jieba
import re
from pathlib import Path
from bertopic import BERTopic
from bertopic.vectorizers import ClassTfidfTransformer
from sentence_transformers import SentenceTransformer
from sklearn.feature_extraction.text import CountVectorizer
from umap import UMAP
from hdbscan import HDBSCAN

# === 1. 路径设置 ===
BASE_DIR = Path("/Users/fushiyi/Desktop/Helsinki/masters_thesis/coding/")
input_file = BASE_DIR / "comments_with_similarity_other.csv"

df = pd.read_csv(input_file)
assert "text" in df.columns, "❌ 缺少 text 欄位"

# === 2. 文本过滤：去娱乐型、短文本 ===
EXCLUDE_PATTERNS = r"(哈哈|好吃|同款|姐妹|来了|冲|点赞|呜呜|爱了|笑死|帅|美|cute|🥰|😭|😅)"
def is_valid(text: str) -> bool:
    text = str(text).strip()
    if len(text) < 5:
        return False
    if re.fullmatch(r"(.)\1{3,}", text):
        return False
    if re.search(EXCLUDE_PATTERNS, text):
        return False
    if not re.search(r"[\u4e00-\u9fa5]", text):
        return False
    return True

texts = [t for t in df["text"].astype(str).tolist() if is_valid(t)]
print(f"💬 有效评论数（用于建模）：{len(texts)}")

# === 3. Jieba 分词器 ===
def jieba_tokenizer(text):
    return [w for w in jieba.cut(text) if len(w.strip()) > 1]

# === 4. 停用词加载（不加入额外“高频无洞察词”）===
stopword_files = [
    BASE_DIR / "HIT.txt",
    BASE_DIR / "scu_stopwords.txt",
    BASE_DIR / "cn_stopwords.txt",
    BASE_DIR / "baidu_stopwords.txt",
    BASE_DIR / "stopwords-zh.txt"
]

stop_words = set()
for file in stopword_files:
    try:
        with open(file, encoding="utf-8") as f:
            stop_words.update([w.strip() for w in f if w.strip()])
    except FileNotFoundError:
        print(f"⚠️ 未找到文件：{file}")

stop_words = sorted(stop_words)
print(f"✅ 共加载停用词 {len(stop_words)} 个")

# === 5. 向量化与模型组件 ===
vectorizer_model = CountVectorizer(
    tokenizer=jieba_tokenizer,
    stop_words=stop_words,
    min_df=2,
    max_df=0.95
)
ctfidf_model = ClassTfidfTransformer()
embedding_model = SentenceTransformer("Alibaba-NLP/gte-multilingual-base", trust_remote_code=True)

# === 6. 降维与聚类 ===
umap_model = UMAP(
    n_neighbors=20,
    n_components=6,
    min_dist=0.15,
    metric="cosine",
    random_state=42
)
hdbscan_model = HDBSCAN(
    min_cluster_size=18,
    min_samples=8,
    metric="euclidean",
    cluster_selection_method='leaf'
)

# === 7. 构建 BERTopic 模型 ===
topic_model = BERTopic(
    embedding_model=embedding_model,
    vectorizer_model=vectorizer_model,
    ctfidf_model=ctfidf_model,
    umap_model=umap_model,
    hdbscan_model=hdbscan_model,
    top_n_words=12,
    language="chinese"
)
topics, probs = topic_model.fit_transform(texts)
topic_model.reduce_topics(texts, nr_topics=4)

# === 9. 输出主题摘要 ===
topic_info = topic_model.get_topic_info()
topic_info.to_excel(BASE_DIR / "topic_summary_comments_paper_v8_raw.xlsx", index=False)

# === 10. 输出关键词权重 ===
keywords_weighted = []
for topic_id, words in topic_model.get_topics().items():
    if topic_id == -1:
        continue
    for word, weight in words:
        keywords_weighted.append({"topic": topic_id, "word": word, "weight": weight})
pd.DataFrame(keywords_weighted).to_excel(BASE_DIR / "topic_keywords_comments_paper_v8_raw.xlsx", index=False)

# === 11. 输出代表性评论 ===
rep_docs = topic_model.get_representative_docs()
rep_data = []
for topic_id, docs in rep_docs.items():
    if topic_id == -1:
        continue
    for i, doc in enumerate(docs[:3]):
        rep_data.append({"topic": topic_id, "rank": i+1, "representative_text": doc})
pd.DataFrame(rep_data).to_excel(BASE_DIR / "topic_representative_comments_paper_v8_raw.xlsx", index=False)

# === 12. 可视化 & 保存模型 ===
try:
    topic_model.visualize_topics().write_html(str(BASE_DIR / "topics_visualization_comments_paper_v8_raw.html"))
except Exception as e:
    print("⚠️ 可视化失败：", e)

topic_model.save(str(BASE_DIR / "bertopic_model_comments_paper_v8_raw"))
print("✅ v8 模型训练完成（无高频无洞察词过滤版）")
print("📊 输出：topic_summary_comments_paper_v8_raw.xlsx / topic_keywords_comments_paper_v8_raw.xlsx / topic_representative_comments_paper_v8_raw.xlsx")
