import pandas as pd
from pathlib import Path
import re
import emoji
from opencc import OpenCC
from natsort import natsorted

# === 1) 路径 & 文件加载 ===
BASE_DIR = Path("/Users/fushiyi/Desktop/Helsinki/master's thesis/coding")
files = natsorted((BASE_DIR / "data").glob("data_scraped*.csv"))
assert files, "❌ No files matched pattern: data_scraped*.csv"
print("📂 共找到文件：", len(files))

# === 2) 合并所有文件 ===
dfs = []
for f in files:
    df = pd.read_csv(f, encoding="utf-8", engine="python")
    df["source_file"] = f.name
    dfs.append(df)
comments = pd.concat(dfs, ignore_index=True)

# === 3) 统一列名 & 映射 ===
comments.columns = comments.columns.str.strip().str.lower()
name_map = {
    "post_id": "post_id", "postid": "post_id", "note_id": "post_id", "post": "post_id",
    "comment": "text", "comment_text": "text", "content": "text", "text": "text",
    "user": "user", "username": "user", "author": "user", "user_name": "user",
    "date": "date", "time": "date", "created_at": "date", "created_time": "date",
    "like_count": "likes", "likes": "likes", "like": "likes", "liked_count": "likes"
}
comments = comments.rename(columns={c: name_map[c] for c in comments.columns if c in name_map})

# === 4) 必需列检查 ===
required = {"post_id", "text"}
missing = required - set(comments.columns)
assert not missing, f"Missing required columns: {missing}"

# === 5) 简繁转换器初始化 ===
cc = OpenCC('t2s')  # 繁体 -> 简体

# === 6) 初步清洗 ===
def clean_preserve_raw(text: str) -> str:
    text = str(text)
    text = re.sub(r"http\S+", "", text)                  # 去链接
    text = re.sub(r"[@#]\S+", "", text)                  # 去 @ 和 #
    text = re.sub(r"\[[^\[\]]{1,6}\]", "", text)         # 去表情标签如 [捂脸]
    text = emoji.replace_emoji(text, replace='')         # 去 emoji
    text = cc.convert(text)                              # 繁体转简体
    text = re.sub(r"[。，、？！；：“”‘’（）…—·【】《》〈〉]", "", text)  # 去中文标点
    text = re.sub(r"[^\w\s\u4e00-\u9fa5]", "", text)     # 去特殊符号
    text = re.sub(r"\s+", " ", text).strip()             # 清理多余空格
    return text

comments["text"] = comments["text"].astype(str).apply(clean_preserve_raw)
comments = comments[comments["text"].str.strip() != ""]

# === 7) 情绪保留 + 广告/噪声剔除 ===
def tag_emotion(text):
    text = str(text)

    # 屏蔽噪声关键词
    noise = ["zzd", "甄子丹", "浙政钉"]
    if any(noise_word.lower() in text.lower() for noise_word in noise):
        return None

    # 屏蔽广告/引流关键词
    block_keywords = [
        "邀请码", "复制口令", "长按复制", "专属链接", "打开小红书", "加入该群",
        "扫码加入", "加我微信", "点击领取", "赚零花钱", "免费送", "推广奖励",
        "引流", "邀请码消息", "私信我", "扫码", "限时秒杀", "邀请好友",
        "评论区我看到", "CZ1510", "信息汇集群", "群聊", "赶紧上车",
        "发发美图带带货", "霸道总裁爱上绝经", "考公博主", "小红书"
    ]
    if re.search("|".join(block_keywords), text, flags=re.IGNORECASE):
        return None

    # 剔除重复字符构成的评论，例如“哈哈哈”，“……”，“。。。。”
    if re.fullmatch(r"(.)\1{3,}", text):
        return None

    # 过滤短文本或无中文字符的
    if len(text) < 4 or not re.search(r"[\u4e00-\u9fa5]", text):
        return None

    return text.strip()

comments["raw_text"] = comments["text"]
comments["cleaned_text"] = comments["text"].apply(tag_emotion)

# 移除无效文本
removed_ads = comments[comments["cleaned_text"].isna()]
comments = comments[comments["cleaned_text"].notna()]
removed_ads.to_csv(BASE_DIR / "removed_for_ads_emotion.csv", index=False, encoding="utf-8-sig")

# 更新主文本列
comments["text"] = comments["cleaned_text"]
comments = comments.drop(columns=["cleaned_text"])

# === 8) 类型转换 ===
if "date" in comments.columns:
    comments["date"] = pd.to_datetime(comments["date"], errors="coerce")
if "likes" in comments.columns:
    comments["likes"] = pd.to_numeric(comments["likes"], errors="coerce")

# === 9) 添加评论长度列，便于分析 ===
comments["text_len"] = comments["text"].apply(len)

# === 10) 去重 ===
comments = comments.dropna(subset=["text", "post_id"])
comments = comments.drop_duplicates(subset=["post_id", "text"])
comments = comments.drop_duplicates(subset=["text"])  # 进一步去除不同 post 下相同评论

# === 11) 保存清洗后数据 ===
out_path = BASE_DIR / "comments_clean.csv"
comments.to_csv(out_path, index=False)
print(f"✅ Cleaned comments saved to: {out_path}")
print(f"📊 Shape: {comments.shape}")
print("📈 每个 post_id 评论数描述：")
print(comments.groupby("post_id").size().describe())
