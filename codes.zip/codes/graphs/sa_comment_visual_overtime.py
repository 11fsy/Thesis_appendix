import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

# === Load comment sentiment results ===
df = pd.read_csv("comment_final_binary_result.csv")

# === Convert date and apply threshold ===
df["date"] = pd.to_datetime(df["date"])
df["month"] = df["date"].dt.to_period("M").astype(str)
df["label_by_0.7"] = df["positive_score"].apply(lambda x: "Positive" if x > 0.7 else "Negative")

# === Compute sentiment share per month ===
emotion = df.groupby("month")["label_by_0.7"].value_counts().unstack(fill_value=0)
emotion_pct = emotion.div(emotion.sum(axis=1), axis=0) * 100
emotion_pct = emotion_pct.sort_index()

# === Plot style ===
mpl.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans']
mpl.rcParams['axes.unicode_minus'] = False

COLOR_POS = "#0072B2"  # Blue
COLOR_NEG = "#999999"  # Gray

fig, ax = plt.subplots(figsize=(14, 7))

# === Draw stacked bars ===
pos_bars = ax.bar(
    emotion_pct.index,
    emotion_pct["Positive"],
    color=COLOR_POS,
    label="Positive (>0.7)"
)

neg_bars = ax.bar(
    emotion_pct.index,
    emotion_pct["Negative"],
    bottom=emotion_pct["Positive"],
    color=COLOR_NEG,
    label="Negative (≤0.7)"
)

# === Add labels (centered inside segments) ===
for i, month in enumerate(emotion_pct.index):

    if emotion_pct["Positive"].iloc[i] > 0:
        ax.text(
            i,
            emotion_pct["Positive"].iloc[i] / 2,
            f"{emotion_pct['Positive'].iloc[i]:.0f}%",
            ha="center",
            va="center",
            fontsize=10,
            color="white",
            weight="bold"
        )

    if emotion_pct["Negative"].iloc[i] > 0:
        ax.text(
            i,
            emotion_pct["Positive"].iloc[i] + emotion_pct["Negative"].iloc[i] / 2,
            f"{emotion_pct['Negative'].iloc[i]:.0f}%",
            ha="center",
            va="center",
            fontsize=10,
            color="black"
        )

# === Titles & Axis Labels ===
ax.set_title("Sentiment Composition Over Time in Comments", fontsize=22)  # <<< Consistent size
ax.set_ylabel("Share of Comments (%)", fontsize=16)
ax.set_xlabel("Time (Monthly)", fontsize=16)
ax.set_ylim(0, 100)

plt.xticks(rotation=45, fontsize=11)
plt.yticks(fontsize=11)

# === Legend and formatting ===
ax.legend(fontsize=12, loc="upper right")
ax.grid(axis="y", linestyle="--", alpha=0.18)

for spine in ax.spines.values():
    spine.set_linewidth(1.2)

plt.tight_layout()
plt.show()
