# ============================================
# Intertopic Distance Map for Your Dataset
# ============================================

from bertopic import BERTopic
from sklearn.feature_extraction.text import CountVectorizer
from umap import UMAP
import hdbscan
import pandas as pd
import plotly.io as pio
import matplotlib.pyplot as plt

from bertopic_comment import BASE_DIR

# ------------------------------
# 1. Load dataset
# ------------------------------
df = pd.read_excel(BASE_DIR / "post_clean.csv")

# If your documents are in another file, update accordingly.
# Replace "text" with the real column name.
docs = df["text"].astype(str).tolist()


# ------------------------------
# 2. Configure UMAP + HDBSCAN
# ------------------------------
umap_model = UMAP(
    n_neighbors=15,
    n_components=2,
    min_dist=0.0,
    metric="cosine",
    random_state=42
)

hdbscan_model = hdbscan.HDBSCAN(
    min_cluster_size=10,
    metric='euclidean',
    cluster_selection_method='leaf',
    prediction_data=True
)


# ------------------------------
# 3. Vectorizer — optimized for Chinese + English
# ------------------------------
vectorizer_model = CountVectorizer(
    stop_words="english",
    token_pattern=r"(?u)\b\w+\b"
)


# ------------------------------
# 4. Train BERTopic
# ------------------------------
topic_model = BERTopic(
    umap_model=umap_model,
    hdbscan_model=hdbscan_model,
    vectorizer_model=vectorizer_model,
    calculate_probabilities=True,
    verbose=True
)

topics, probs = topic_model.fit_transform(docs)


# ------------------------------
# 5. Plotly Intertopic Distance Map
# ------------------------------
fig = topic_model.visualize_topics(
    title="Intertopic Distance Map",
    width=1200,
    height=900
)

# Save interactive HTML
html_path = BASE_DIR / "intertopic_distance_map.html"
fig.write_html(html_path)
print(f"Interactive map saved to: {html_path}")


# ------------------------------
# 6. OPTIONAL: Save Static PNG with All Labels
# ------------------------------
# Convert Plotly figure to static image via Kaleido
png_path = BASE_DIR / "intertopic_distance_map.png"

pio.write_image(
    fig, 
    png_path,
    width=1400,
    height=1100,
    scale=2
)

print(f"Static PNG saved to: {png_path}")


# ------------------------------
# 7. Show map in notebook
# ------------------------------
fig.show()


print("\n🎉 Intertopic Distance Map created successfully!")
