# === 相似度分析腳本 ===
import pandas as pd
from sentence_transformers import SentenceTransformer, util
from pathlib import Path
import torch

# === 1. 路徑設定 ===
input_file = "comments_clean.csv"
output_file = "comments_with_similarity.csv"

# === 2. 讀取資料 ===
df = pd.read_csv(input_file)
assert "text" in df.columns, "❌ 缺少 text 欄位"

texts = df["text"].astype(str).tolist()
print(f"📄 文本數量：{len(texts)}")

# === 3. 載入中文語義模型 ===
print("🚀 載入模型中...")
model = SentenceTransformer("shibing624/text2vec-base-chinese")

# === 4. 定義四個主題類別 ===
categories = ["家庭", "工作", "情緒", "其他"]
category_embeddings = model.encode(categories, convert_to_tensor=True)

# === 5. 計算相似度 ===
print("🔍 計算語義相似度中...")
text_embeddings = model.encode(texts, convert_to_tensor=True, show_progress_bar=True)
cosine_scores = util.cos_sim(text_embeddings, category_embeddings)  # shape: (num_texts, 4)

# === 6. 將結果轉換為 DataFrame ===
scores = cosine_scores.cpu().numpy()
for i, cat in enumerate(categories):
    df[f"sim_{cat}"] = scores[:, i]

# === 7. 取出最高分類別 ===
df["最高類別"] = df[[f"sim_{c}" for c in categories]].idxmax(axis=1)
df["最高類別"] = df["最高類別"].str.replace("sim_", "", regex=False)

# === 8. 儲存結果 ===
df.to_csv(output_file, index=False, encoding="utf-8-sig")
print(f"✅ 已儲存結果至：{output_file}")
print(df.head())
