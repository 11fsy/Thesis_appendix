import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
import re

# ===============================
# 1. File paths
# ===============================
BASE_DIR = Path("/Users/fushiyi/Desktop/Helsinki/masters_thesis/coding")
sentiment_file = BASE_DIR / "post_final_binary_result.csv"
topic_dir = BASE_DIR / "topic_outputs_originalparams"

# ===============================
# 2. Load all topic CSV files
# ===============================
topic_files = sorted(
    topic_dir.glob("topic_*.csv"),
    key=lambda f: int(re.findall(r"\d+", f.stem)[0])
)

if not topic_files:
    raise ValueError("❌ No topic_*.csv files found in topic_outputs_originalparams")

df_topics = pd.concat([pd.read_csv(f) for f in topic_files], ignore_index=True)

# ===============================
# 3. Load sentiment file
# ===============================
df_sent = pd.read_csv(sentiment_file)

assert "positive_score" in df_sent.columns, "❌ sentiment file missing 'positive_score'"
assert "topic" in df_topics.columns, "❌ topic files missing 'topic' column"

# ===============================
# 4. Merge (topic + sentiment)
# ===============================
df = pd.concat([df_topics, df_sent["positive_score"]], axis=1)
df = df[df["topic"] != -1]  # Remove noise

# ===============================
# 5. Categorize sentiment
# ===============================
df["sentiment"] = df["positive_score"].apply(lambda x: "Positive" if x >= 0.5 else "Negative")

# ===============================
# 6. Clean topic labels and calculate sentiment proportions
# ===============================
df = df[df["topic"].notna()]  # Drop NaN topics
df["topic"] = df["topic"].astype(int)  # Safe to convert now

df_counts = df.groupby(["topic", "sentiment"]).size().unstack(fill_value=0)
df_props = df_counts.div(df_counts.sum(axis=1), axis=0)
df_props = df_props.sort_values(by="Positive", ascending=False)

topic_labels = [f"Topic {t}" for t in df_props.index]


# ===============================
# 7. Plot stacked bar chart
# ===============================
fig, ax = plt.subplots(figsize=(12, 7))

colors = {
    "Negative": "#999999",  # gray
    "Positive": "#0072B2"   # blue
}

df_props.plot(
    kind="bar",
    stacked=True,
    ax=ax,
    color=[colors[col] for col in df_props.columns],
    width=0.6,
    edgecolor="black"
)

# Add percentage labels
for i, topic in enumerate(df_props.index):
    bottom = 0
    for sentiment in df_props.columns:
        value = df_props.loc[topic, sentiment]
        if value > 0.01:
            ax.text(
                i,
                bottom + value / 2,
                f"{value:.0%}",
                ha="center",
                va="center",
                fontsize=11,
                color="white" if sentiment == "Positive" else "black"
            )
        bottom += value

# Axis labels (font sizes from your original chart — unchanged)
ax.set_xticks(range(len(topic_labels)))
ax.set_xticklabels(topic_labels, rotation=0)
ax.set_ylabel("Proportion",fontsize=12)
ax.set_xlabel("Topics",fontsize=12)  # ✅ Only this line added
ax.set_title("Sentiment Proportion by Topic",fontsize=16)
ax.legend(title="Sentiment")
ax.grid(axis='y', linestyle='--', alpha=0.4)

ax.set_facecolor("white")
fig.patch.set_facecolor("white")

plt.tight_layout()
plt.show()
