from DrissionPage import ChromiumPage
from datetime import datetime
import csv

# 创建文件对象
f = open('data_scraped79.csv', mode='w', encoding='utf-8', newline='')
csv_writer = csv.DictWriter(f, fieldnames=[
    'Comment_id',
    'Post_id',
    'Date',
    'Like_count',
    'Comment_count',
    'Location',
    'Comment'
])
csv_writer.writeheader()

# 打开浏览器并监听数据包
dp = ChromiumPage()
dp.listen.start('comment/page')

# 帖子链接列表（可添加多个帖子的 URL）
post_urls = [
    'https://www.xiaohongshu.com/explore/67a75aa2000000001701f33e?xsec_token=ABWCRlfQQMqyFkGEKdKXhQO-GfysF8Mlnq4LgeQ2noy0I=&xsec_source=',
    'https://www.xiaohongshu.com/explore/68106ed1000000002202eb8b?xsec_token=AB4omrrDdBJZ_QD1M-nXWOnUTOcJjxQlyxNlzcjFE24Fc=&xsec_source=',
    'https://www.xiaohongshu.com/explore/684821cf0000000022004599?xsec_token=ABWTWrkh0qQhxliJ6Qi-W0L2UHkLaWx6WCgd3Liz6iu2U=&xsec_source=',
    'https://www.xiaohongshu.com/explore/684461a6000000002001f389?xsec_token=ABbwF_RQiNn_mRvs-CFWC2utPzmUSUNpJSO7qTwWm-Lg4=&xsec_source=',
    'https://www.xiaohongshu.com/explore/64983aed0000000011012c62?xsec_token=ABo5E5O-e90pJtyWN55AdHTl-AAidj9tyiQ9o8WZMt2C4=&xsec_source=',
    'https://www.xiaohongshu.com/explore/6488451e000000001300e07c?xsec_token=ABVj_IFkxtvK_bagQ5RQsFLJyn-Ubyv2pS7xcO5lfEgJc=&xsec_source=',
    'https://www.xiaohongshu.com/explore/6428e4dc0000000013034c8b?xsec_token=AB2yR2FMn4MKSSdxTrrtZs66FmRwYjQ4cdg-iErFy_sOg=&xsec_source=',
    'https://www.xiaohongshu.com/explore/67a436c1000000001701f679?xsec_token=ABYEmupG1ErH1rcDubNRheDpNI4jJp3UdR0D483YoDivs=&xsec_source=',
    'https://www.xiaohongshu.com/explore/686b3b350000000015020db8?xsec_token=ABwwGsGk4fF8XI8oPiES-gxVXvFytKSKKGWeHnZTz1NHE=&xsec_source=',
    'https://www.xiaohongshu.com/explore/63c2bc7d000000001b015ea5?xsec_token=ABqB81B9HWzXFkK9yGrfNRenfRWDOkRHiYSit_RfFoCeY=&xsec_source=',
    'https://www.xiaohongshu.com/explore/690bd62e000000000301ead4?xsec_token=ABKJ_HMJjRxQ2jnI9zp7-cp7RuCyipczCywRk0_mJdBoc=&xsec_source=',
    'https://www.xiaohongshu.com/explore/67dc8c06000000001d01f0d4?xsec_token=AB_3zIQdASQPZ_TUF1rVXmmomgvmav64DGYvRWe2IZ2Ns=&xsec_source=',
    'https://www.xiaohongshu.com/explore/68fb69f0000000000401369f?xsec_token=ABnyU2hNI3HEwDbAlu_3k7qVzfFzF_ny1EStjp0KP1E_A=&xsec_source=',
    'https://www.xiaohongshu.com/explore/689349320000000005004802?xsec_token=AB-ruLOCXGzon4EjTiJuUJm16UcSq9HGY-YwXwg1qlOJs=&xsec_source=',
    'https://www.xiaohongshu.com/explore/680f852500000000210015f0?xsec_token=ABOJgipJdqAFxFJACB4SYXkw4ICutoS7X4c4bHsz6crYo=&xsec_source=',
    'https://www.xiaohongshu.com/explore/682d82e0000000000303cd88?xsec_token=ABlGAGlExFAAUqFUTDqABjZrBx5xVO4tobVmTp6DnHryo=&xsec_source=',
    'https://www.xiaohongshu.com/explore/683e900b0000000023001a38?xsec_token=ABeynJjlENTt3_oeNs3fnAY9DJOSp_LnnxXeYzefDnzrk=&xsec_source=',
    'https://www.xiaohongshu.com/explore/64fd75530000000013036483?xsec_token=ABiOm33pnV4SO6HpSlZr5OIYGZqjELUjv_aCCaGX92Zfk=&xsec_source=',
    'https://www.xiaohongshu.com/explore/667d37bd000000001e0137e5?xsec_token=ABAUzB8ssxK51WJ-IZ8ssWFkRqMldeo94ZkFS_IelUkTk=&xsec_source=',
    'https://www.xiaohongshu.com/explore/688796c600000000130122d3?xsec_token=ABbP1IPnWaHiIoafF2QVOJIvqYmOtJVIa0eWjrJcYlmuE=&xsec_source=',
    'https://www.xiaohongshu.com/explore/672c8b2200000000190185b0?xsec_token=ABgGufbtsSkDhGVHXlEV44y56NedVOW0suqztKiK8SEXI=&xsec_source='
]

# 定义一个函数抓取单个帖子的评论
def scrape_post_comments(post_url):
    note_id = post_url.split('/explore/')[-1].split('?')[0]
    dp.get(post_url)
    
    page = 1
    while True:
        print(f'\n正在采集帖子 {note_id} 第{page}页')

        # 等待加载评论数据包
        r = dp.listen.wait()
        json_data = r.response.body

        # 处理评论数据
        comments = json_data['data'].get('comments', [])
        if not comments:
            print("未获取到评论，跳过此页")
            break

        for index in comments:
            ip_location = index.get('ip_location', 'Unknown')
            t = str(index['create_time'])[:-3]
            date = str(datetime.fromtimestamp(int(t)))

            dit = {
                'Comment_id': index['id'],
                'Post_id': note_id,
                'Date': date,
                'Like_count': index['like_count'],
                'Comment_count': index['sub_comment_count'],
                'Location': ip_location,
                'Comment': index['content'],
            }

            csv_writer.writerow(dit)
            print(dit)

            # 可选：滚动评论位置
            try:
                id_ = index['id']
                tab = dp.ele(f'#comment-{id_}')
                dp.scroll.to_see(tab)
            except Exception as e:
                print(f'滚动失败: {e}')

        # 判断是否有更多页
        has_more = json_data['data'].get('has_more', False)
        if not has_more:
            print(f"帖子 {note_id} 评论采集完毕。")
            break

        page += 1

# 遍历每个帖子URL并采集评论
for post_url in post_urls:
    try:
        scrape_post_comments(post_url)
    except Exception as e:
        print(f'采集出错，跳过当前帖文: {e}')

# 关闭文件
f.close()
print("全部采集完成。")
