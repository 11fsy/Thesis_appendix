from scipy.stats import binom_test

n_pos = 87     # <-- replace with your number
n_total = 103

p_value = binom_test(n_pos, n_total, p=0.5, alternative="greater")
print(p_value)
