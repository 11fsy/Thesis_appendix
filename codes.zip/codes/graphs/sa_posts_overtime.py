import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

# === Load and prepare data ===
df = pd.read_csv("post_final_binary_result.csv")
df["date"] = pd.to_datetime(df["date"])
df["label"] = df["positive_score"].apply(lambda x: "Positive" if x > 0.7 else "Negative")
df["month"] = df["date"].dt.to_period("M").astype(str)

# === Group and convert to percentages ===
emotion = df.groupby("month")["label"].value_counts().unstack(fill_value=0)
emotion_pct = emotion.div(emotion.sum(axis=1), axis=0) * 100
emotion_pct = emotion_pct.sort_index()

# === Global styling ===
mpl.rcParams['font.sans-serif'] = ['Arial']
mpl.rcParams['axes.unicode_minus'] = False

COLOR_POS = "#0072B2"  # blue
COLOR_NEG = "#999999"  # gray

fig, ax = plt.subplots(figsize=(14, 7))

# === Stacked bars ===
pos_bars = ax.bar(
    emotion_pct.index,
    emotion_pct["Positive"],
    color=COLOR_POS,
    label="Positive (>0.7)"
)

neg_bars = ax.bar(
    emotion_pct.index,
    emotion_pct["Negative"],
    bottom=emotion_pct["Positive"],
    color=COLOR_NEG,
    label="Negative (≤0.7)"
)

# === Labels inside bars ===
for i, month in enumerate(emotion_pct.index):

    # Positive
    if emotion_pct["Positive"].iloc[i] > 0:
        ax.text(
            i,
            emotion_pct["Positive"].iloc[i] / 2,
            f"{emotion_pct['Positive'].iloc[i]:.0f}%",
            ha="center",
            va="center",
            fontsize=10,
            weight="bold",
            color="white"
        )

    # Negative
    if emotion_pct["Negative"].iloc[i] > 0:
        ax.text(
            i,
            emotion_pct["Positive"].iloc[i] + emotion_pct["Negative"].iloc[i] / 2,
            f"{emotion_pct['Negative'].iloc[i]:.0f}%",
            ha="center",
            va="center",
            fontsize=10,
            color="black"
        )

# === Titles & Labels (Consistent with your other plots) ===
ax.set_title(
    "Sentiment Composition Over Time in Posts",
    fontsize=22
)

ax.set_ylabel("Share of Posts (%)", fontsize=16)
ax.set_xlabel("Time (Monthly)", fontsize=16)
ax.set_ylim(0, 100)

plt.xticks(rotation=45, fontsize=11)
plt.yticks(fontsize=11)

# === Legend & Styling ===
ax.legend(fontsize=12, loc="upper right")

for spine in ax.spines.values():
    spine.set_linewidth(1.2)

ax.grid(axis='y', linestyle='--', alpha=0.20)

plt.tight_layout()
plt.show()
