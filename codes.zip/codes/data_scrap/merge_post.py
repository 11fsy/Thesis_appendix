import pandas as pd
from pathlib import Path

# === Paths ===
BASE_DIR = Path("/Users/fushiyi/Desktop/Helsinki/master's thesis/coding/post_data")

post_file = BASE_DIR / "30_posts_data.csv"
extra_posts_path1 = BASE_DIR / "only_posts.csv"
extra_posts_path2 = BASE_DIR / "6_posts_data.csv"
extra_posts_path3 = BASE_DIR / "extra_posts_data.csv"

# === Read all CSV files into dataframes ===
df1 = pd.read_csv(post_file)
df2 = pd.read_csv(extra_posts_path1)
df3 = pd.read_csv(extra_posts_path2)
df4 = pd.read_csv(extra_posts_path3)

# === Merge vertically (stack / append) ===
df_merged = pd.concat([df1, df2, df3, df4], ignore_index=True)

# === Save merged file ===
output_path = BASE_DIR / "merged_posts_data.csv"
df_merged.to_csv(output_path, index=False, encoding="utf-8")

print("✅ Merge completed!")
print(f"📁 Saved as: {output_path}")
print(f"📊 Total rows: {len(df_merged)}")

# === Character count metrics ===

# Ensure missing values don't break length counting
df_merged["title"] = df_merged["Title"].fillna("")
df_merged["text"] = df_merged["Content"].fillna("")

# Compute character lengths
df_merged["title_len"] = df_merged["title"].str.len()
df_merged["content_len"] = df_merged["text"].str.len()
df_merged["combined_len"] = df_merged["title_len"] + df_merged["content_len"]

# Summary dictionary
summary = {
    "Metric": ["Total Characters", "Longest Text (characters)", "Shortest Text (characters)", "Average Length (characters)"],
    "Title": [
        df_merged["title_len"].sum(),
        df_merged["title_len"].max(),
        df_merged["title_len"].min(),
        round(df_merged["title_len"].mean(), 2)
    ],
    "Content": [
        df_merged["content_len"].sum(),
        df_merged["content_len"].max(),
        df_merged["content_len"].min(),
        round(df_merged["content_len"].mean(), 2)
    ],
    "Title + Content": [
        df_merged["combined_len"].sum(),
        df_merged["combined_len"].max(),
        df_merged["combined_len"].min(),
        round(df_merged["combined_len"].mean(), 2)
    ]
}

summary_df = pd.DataFrame(summary)

print("\n===== Character Length Summary =====")
print(summary_df)

# Export summary
summary_df.to_csv(BASE_DIR / "character_length_summary.csv", index=False, encoding="utf-8")
print("\n✅ Summary exported as: character_length_summary.csv")

