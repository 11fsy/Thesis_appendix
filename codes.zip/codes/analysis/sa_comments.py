import pandas as pd
import re
from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline

# === 1. Model Settings ===
model_name = "IDEA-CCNL/Erlangshen-Roberta-110M-Sentiment"

tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSequenceClassification.from_pretrained(model_name, use_safetensors=True)

sentiment_pipeline = pipeline(
    "text-classification",
    model=model,
    tokenizer=tokenizer,
    top_k=None   # replaces deprecated return_all_scores
)

# === 2. Load Data ===
input_path = "comments_clean.csv"
df = pd.read_csv(input_path)
assert "text" in df.columns, "❌ CSV is missing 'text' column"

# === 3. Clean Text ===
def clean_text(text):
    text = str(text)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"(http\S+|www\S+)", "", text)
    text = re.sub(r"[#@【】\[\]（）()]+", "", text)
    return text.strip()

positive_scores = []
pred_labels = []

# === 4. Sentiment Analysis (Binary with threshold = 0.7) ===
for text in df["text"]:
    text = clean_text(text)

    if not text:
        positive_scores.append(0.0)
        pred_labels.append("Negative")
        continue

    # New pipeline output: [[{label, score}, {label, score}]]
    outputs = sentiment_pipeline(text[:256])
    scores = outputs[0]  # unpack

    # Extract positive score
    positive_score = None
    for s in scores:
        if s["label"].lower() == "positive":
            positive_score = s["score"]

    if positive_score is None:
        positive_score = 0.0

    # === Threshold at 0.7 ===
    label = "Positive" if positive_score > 0.7 else "Negative"

    positive_scores.append(positive_score)
    pred_labels.append(label)

# === 5. Save Results ===
df["positive_score"] = positive_scores
df["predicted_label"] = pred_labels

output_path = "comment_final_binary_result.csv"
df.to_csv(output_path, index=False, encoding="utf-8-sig")

print("🎉 Comment sentiment analysis complete! Saved to:", output_path)
print(df["predicted_label"].value_counts())
