import matplotlib.pyplot as plt
import pandas as pd
from pathlib import Path

# =============================
# === Paths ===
# =============================
BASE_DIR = Path("./")
INPUT_FILE = BASE_DIR / "pipeline_output" / "merged_comments_topics.csv"
OUTPUT_DIR = BASE_DIR / "pipeline_output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# =============================
# === Load data ===
# =============================
df = pd.read_csv(INPUT_FILE)

# Remove outlier / noise topic
df = df[df["topic"] != -1]

# Count comments per topic
comment_counts = df.groupby("topic").size().sort_index()

# =============================
# 📊 AESTHETIC BAR CHART
# =============================
fig, ax = plt.subplots(figsize=(9, 5.5))

bars = ax.bar(
    [f"Topic {int(t)}" for t in comment_counts.index],
    comment_counts.values,
    width=0.6,                      # ✅ column width
    color="#0072B2",
    edgecolor="#4D4D4D",
    linewidth=0.8
)

# --- Title & labels ---
ax.set_title("Number of Comments per Post Topic", fontsize=12, pad=12)
ax.set_xlabel("Post Topic", fontsize=9)
ax.set_ylabel("Number of Comments", fontsize=9)

# --- Expand y-axis to avoid label overlap ---
ax.set_ylim(0, 4000)

# --- Grid (subtle, academic style) ---
ax.grid(axis="y", linestyle="--", alpha=0.4)

# --- Full plot borders (spines) ---
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_color("#4D4D4D")
    spine.set_linewidth(0.8)

# --- Value labels above bars ---
y_offset = max(comment_counts.values) * 0.02

for bar in bars:
    height = bar.get_height()
    ax.text(
        bar.get_x() + bar.get_width() / 2,
        height + y_offset,
        f"{int(height)}",
        ha="center",
        va="bottom",
        fontsize=10
    )

# =============================
# === Save figure ===
# =============================
plt.tight_layout()
plt.savefig(
    OUTPUT_DIR / "comment_count_per_topic.png",
    dpi=300,
    bbox_inches="tight"
)
plt.close()
