import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# 1. File Paths
# ============================================================
POST_FILE = "post_final_binary_result.csv"
COMMENT_FILE = "comment_final_binary_result.csv"
OUTPUT_MATRIX_CSV = "post_comment_sentiment_matrix.csv"
OUTPUT_FIG = "post_comment_sentiment_heatmap.png"

# ============================================================
# 2. Load Sentiment Results
# ============================================================
posts = pd.read_csv(POST_FILE)
comments = pd.read_csv(COMMENT_FILE)

posts = posts.rename(columns={"predicted_label": "post_sentiment"})
comments = comments.rename(columns={"predicted_label": "comment_sentiment"})

df = comments.merge(posts[["post_id", "post_sentiment"]], on="post_id", how="left")

# ============================================================
# 3. Build 2×2 Matrix
# ============================================================
ct = (
    pd.crosstab(df["comment_sentiment"], df["post_sentiment"], normalize="columns") * 100
).round(2)

ct.to_csv(OUTPUT_MATRIX_CSV, encoding="utf-8-sig")
print(ct)

# ============================================================
# 4. Plot — Updated Font Sizes
# ============================================================

plt.figure(figsize=(7, 5))

# Color-blind friendly palette ("PuOr")
cmap = plt.get_cmap("PuOr")
plt.imshow(ct, cmap=cmap, aspect="equal")

# Cell borders
for i in range(ct.shape[0]):
    for j in range(ct.shape[1]):
        plt.gca().add_patch(plt.Rectangle(
            (j - 0.5, i - 0.5),
            1, 1,
            fill=False,
            edgecolor="black",
            linewidth=2
        ))

# Cell text: % with 2 decimals
for (i, j), value in np.ndenumerate(ct.values):
    plt.text(
        j, i,
        f"{value:.2f}%",
        ha="center",
        va="center",
        fontsize=14,
        color="black"
    )

# Axis labels and ticks
plt.xticks(range(len(ct.columns)), ct.columns, fontsize=8)
plt.yticks(range(len(ct.index)), ct.index, fontsize=8)
plt.xlabel("Post Sentiment", fontsize=9)
plt.ylabel("Comment Sentiment", fontsize=9)

# Title with consistent style
plt.title(
    "Sentiment Distribution of Comments\nUnder Different Post Sentiments",
    fontsize=12
)

# Colorbar formatting
cbar = plt.colorbar(label="Percentage (%)")
cbar.ax.set_yticklabels([f"{tick:.2f}%" for tick in cbar.get_ticks()])

plt.tight_layout()
plt.show()

print(f"📊 Saved heatmap to: {OUTPUT_FIG}")
