import pandas as pd
from pathlib import Path
import re
import emoji
from opencc import OpenCC

# === 1) 路径设置 ===
BASE_DIR = Path("/Users/fushiyi/Desktop/Helsinki/master's thesis/coding/post_data")

post_file = BASE_DIR / "30_posts_data.csv"
extra_posts_path1 = BASE_DIR / "only_posts.csv"
extra_posts_path2 = BASE_DIR / "6_posts_data.csv"
extra_posts_path3 = BASE_DIR / "extra_posts_data.csv"  # ✅ 避免覆盖

# === 2) 读取数据 ===
posts_30 = pd.read_csv(post_file, encoding="utf-8", engine="python")
posts_5 = pd.read_csv(extra_posts_path1, encoding="utf-8", engine="python")
posts_6 = pd.read_csv(extra_posts_path2, encoding="utf-8", engine="python")
posts_extra = pd.read_csv(extra_posts_path3, encoding="utf-8", engine="python")

# === 3) 合并数据 ===
posts = pd.concat([posts_30, posts_5, posts_6, posts_extra], ignore_index=True)
print("📦 合并后总帖子数:", len(posts))

# === 4) 统一列名 & 映射 ===
posts.columns = posts.columns.str.strip().str.lower()
name_map = {
    "post_id": "post_id", "note_id": "post_id", "id": "post_id",
    "title": "title", "caption": "title",
    "content": "text", "body": "text", "text": "text",
    "date": "date", "created_at": "date", "time": "date",
    "likes": "likes", "like_count": "likes"
}
posts = posts.rename(columns={c: name_map[c] for c in posts.columns if c in name_map})

# 必要列检查
required_cols = {"post_id", "text"}
missing = required_cols - set(posts.columns)
assert not missing, f"❌ 缺少字段: {missing}"

# === 5) 初始化简繁体转换器 ===
cc = OpenCC('t2s')  # 转简体

# === 6) 文本清洗函数 ===
def clean_post_text(text: str) -> str:
    text = str(text)
    text = re.sub(r"http\S+", "", text)                    # 去链接
    text = re.sub(r"[@#]\S+", "", text)                    # 去 @ 和 #
    text = re.sub(r"\[[^\[\]]{1,6}\]", "", text)           # 去 [偷笑] [捂脸] 等
    text = emoji.replace_emoji(text, replace='')           # 去 emoji
    text = cc.convert(text)                                # 繁体转简体
    text = re.sub(r"[。，、？！；：“”‘’（）…—·【】《》〈〉]", "", text)  # 中文标点
    text = re.sub(r"[^\w\s\u4e00-\u9fa5]", "", text)       # 非中英文
    text = re.sub(r"\s+", " ", text).strip()               # 多空格
    return text

# === 7) 清洗文本列 ===
posts["text"] = posts["text"].astype(str).apply(clean_post_text)
if "title" not in posts.columns:
    posts["title"] = ""
else:
    posts["title"] = posts["title"].astype(str).apply(clean_post_text)

# 去空行
posts = posts[posts["text"].str.strip() != ""]

# === 8) 合并 title + text ===
posts["title_text"] = posts["title"].fillna("") + " " + posts["text"].fillna("")

# === 9) 类型转换 & 去重 ===
posts["date"] = pd.to_datetime(posts["date"], errors="coerce")
posts["likes"] = pd.to_numeric(posts.get("likes"), errors="coerce").fillna(0).astype(int)
posts = posts.drop_duplicates(subset=["post_id"])
posts = posts.dropna(subset=["post_id", "text"])
posts = posts[posts["text"].str.len() >= 10]

# === 10) 保存结果 ===
out_path = BASE_DIR / "posts_clean.csv"
posts.to_csv(out_path, index=False, encoding="utf-8-sig")

print(f"✅ 清洗后的数据保存至: {out_path}")
print("📊 数据概览:")
print(posts[["post_id", "title", "text", "title_text"]].head())
print("🧮 文本长度统计：")
print(posts["title_text"].str.len().describe())
